# gistic2
Genomic Identification of Significant Targets in Cancer (GISTIC), version 2.0
